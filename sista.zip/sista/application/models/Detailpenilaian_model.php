<?php 
class Detailpenilaian_model extends CI_Model{
    // membuat property
    public function getAll(){
        // query database, ngambil data table dari phpmyadmin
        $query = $this->db->get('view_detail_penilaian');
        return $query;
    }
    public function getById($id){
        $query = $this->db->get_where('view_detail_penilaian', array('id' => $id));
        return $query;
    }
    public function simpan($data){
        $sql = "INSERT INTO detail_penilaian (penilaian_id,dosen_id,seminar_id,nilai) VALUES (?,?,?,?)";
        
        $this->db->query($sql, $data);

        $insert_id = $this->db->insert_id();
        return $this->findById($insert_id);
    }
        public function findById($id){
            $query = $this->db->get_where('detail_penilaian', array('id'=>$id));
            return $query->row();
        }
        public function update($data){
            // update table kuliner
            $sql = "UPDATE detail_penilaian SET penilaian_id=?,dosen_id=?,seminar_id=?,nilai=? WHERE id=?";
            $this->db->query($sql, $data);
        }
        public function delete($data){
            // update table kuliner
            $sql = "DELETE FROM detail_penilaian WHERE id=?";
            $this->db->query($sql, $data);
        }
}
?>