<?php
class Peserta extends CI_Controller {
    public function index() {
        $this->load->model('peserta_model', 'peserta');
        $data['list_peserta'] = $this->peserta->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('peserta/index', $data);
            $this->load->view('layouts/footer');
    }
    public function create() {
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('peserta/form');
            $this->load->view('layouts/footer');
    }
    public function save(){
        $this->load->model('peserta_model', 'peserta');
        $_nim = $this->input->post('nim');
        $_kehadiran = $this->input->post('kehadiran');
        $_nama_peserta_seminar = $this->input->post('nama_peserta_seminar');
        $_idedit = $this->input->post('idedit');

        $data_peserta['nim']=$_nim;
        $data_peserta['kehadiran']=$_kehadiran;
        $data_peserta['nama_peserta_seminar']=$_nama_peserta_seminar;//?2
    
        if(!empty($_idedit)){// update
            $data_peserta['id']=$_idedit;//?3
            $this->peserta->update($data_peserta);
        }else{//data baru
            $this->peserta->simpan($data_peserta);
        }
        redirect('peserta','refresh');
        /*
        $data['list_dosen'] = $this->dosen->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('dosen/index', $data);
            $this->load->view('layouts/footer'); */
    }
    public function edit($id){
        $this->load->model('peserta_model', 'peserta');
        $obj_peserta = $this->peserta->findById($id);
        $data['objpeserta']=$obj_peserta;
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('peserta/edit', $data);
            $this->load->view('layouts/footer');
    }
    public function delete($id){
        $this->load->model('peserta_model', 'peserta');
        $obj_peserta['id']=$id;
        $this->peserta->delete($obj_peserta);
        redirect('peserta','refresh');
    }
}
?>