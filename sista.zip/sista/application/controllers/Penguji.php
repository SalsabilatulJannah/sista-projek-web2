<?php
class Penguji extends CI_Controller {
    public function index() {
        $this->load->model('penguji_model', 'penguji');
        $data['list_penguji'] = $this->penguji->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('penguji/index', $data);
            $this->load->view('layouts/footer');
    }
    public function create() {
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('penguji/form');
            $this->load->view('layouts/footer');
    }
    public function save(){
        $this->load->model('penguji_model', 'penguji');
        $_nama = $this->input->post('nama_penguji');
        $_idedit = $this->input->post('idedit');

        
        $data_penguji['nama_penguji']=$_nama;//?2
    
        if(!empty($_idedit)){// update
            $data_penguji['id']=$_idedit;//?3
            $this->penguji->update($data_penguji);
        }else{//data baru
            $this->penguji->simpan($data_penguji);
        }
        redirect('penguji','refresh');
        /*
        $data['list_dosen'] = $this->dosen->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('dosen/index', $data);
            $this->load->view('layouts/footer'); */
    }
    public function edit($id){
        $this->load->model('penguji_model', 'penguji');
        $obj_penguji = $this->penguji->findById($id);
        $data['objpenguji']=$obj_penguji;
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('penguji/edit', $data);
            $this->load->view('layouts/footer');
    }
    public function delete($id){
        $this->load->model('penguji_model', 'penguji');
        $data_penguji['id']=$id;
        $this->penguji->delete($data_penguji);
        redirect('penguji','refresh');
    }
}
?>