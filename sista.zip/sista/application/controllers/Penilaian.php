<?php
class Penilaian extends CI_Controller {
    public function index() {
        $this->load->model('penilaian_model', 'penilaian');
        $data['list_penilaian'] = $this->penilaian->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('penilaian/index', $data);
            $this->load->view('layouts/footer');
    }
    public function create() {
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('penilaian/form');
            $this->load->view('layouts/footer');
    }
    public function save(){
        $this->load->model('penilaian_model', 'penilaian');
        $_nama_penilaian = $this->input->post('nama_penilaian');
        $_keterangan = $this->input->post('keterangan');
        $_idedit = $this->input->post('idedit');

        $data_penilaian['nama_penilaian']=$_nama_penilaian;
        $data_penilaian['keterangan']=$_keterangan;//?2
    
        if(!empty($_idedit)){// update
            $data_penilaian['id']=$_idedit;//?3
            $this->penilaian->update($data_penilaian);
        }else{//data baru
            $this->penilaian->simpan($data_penilaian);
        }
        redirect('penilaian','refresh');
        /*
        $data['list_dosen'] = $this->dosen->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('dosen/index', $data);
            $this->load->view('layouts/footer'); */
    }
    public function edit($id){
        $this->load->model('penilaian_model', 'penilaian');
        $obj_penilaian = $this->penilaian->findById($id);
        $data['objpenilaian']=$obj_penilaian;
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('penilaian/edit', $data);
            $this->load->view('layouts/footer');
    }
    public function delete($id){
        $this->load->model('penilaian_model', 'penilaian');
        $obj_penilaian['id']=$id;
        $this->penilaian->delete($obj_penilaian);
        redirect('penilaian','refresh');
    }
}
?>