<?php
class Seminar extends CI_Controller {
    public function index() {
        $this->load->model('seminar_model', 'seminar');
        $data['list_seminar'] = $this->seminar->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('seminar/index', $data);
            $this->load->view('layouts/footer');
    }
    public function create() {
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('seminar/form');
            $this->load->view('layouts/footer');
    }
    /*
    public function jeniswisata(){
        $this->load->model('Jeniswisata_model');
        // memanggil model
        $list_jenis = $this->Jeniswisata_model->getAll();
        $data['list_jenis'] = $list_jenis;
        $this->load->view('layouts/header');
        $this->load->view('wisata/form', $data);
        $this->load->view('layouts/footer');
    }*/
    public function save(){
        $this->load->model('seminar_model', 'seminar');
        $_semester = $this->input->post('semester');
        $_tanggal = $this->input->post('tanggal');
        $_jam = $this->input->post('jam');
        $_kategori_seminar_id = $this->input->post('kategori_seminar_id');
        $_judul = $this->input->post('judul');
        $_pembimbing_id = $this->input->post('pembimbing_id');
        $_penguji1_id = $this->input->post('penguji1_id');
        $_penguji2_id = $this->input->post('penguji2_id');
        $_nilai_pembimbing = $this->input->post('nilai_pembimbing');
        $_nilai_penguji1 = $this->input->post('nilai_penguji1');
        $_nilai_penguji2 = $this->input->post('nilai_penguji2');
        $_lokasi = $this->input->post('lokasi');
        $_nilai_akhir = $this->input->post('nilai_akhir');
        $_peserta_seminar_id = $this->input->post('peserta_seminar_id');
        $_idedit = $this->input->post('idedit');
    
        $data_seminar['semester']=$_semester;//?2
        $data_seminar['tanggal']=$_tanggal;
        $data_seminar['jam']=$_jam;
        $data_seminar['kategori_seminar_id']=$_kategori_seminar_id;
        $data_seminar['judul']=$_judul;
        $data_seminar['pembimbing_id']=$_pembimbing_id;
        $data_seminar['penguji1_id']=$_penguji1_id;
        $data_seminar['penguji2_id']=$_penguji2_id;
        $data_seminar['nilai_pembimbing']=$_nilai_pembimbing;
        $data_seminar['nilai_penguji1']=$_nilai_penguji1;
        $data_seminar['nilai_penguji2']=$_nilai_penguji2;
        $data_seminar['lokasi']=$_lokasi;
        $data_seminar['nilai_akhir']=$_nilai_akhir;
        $data_seminar['peserta_seminar_id']=$_peserta_seminar_id;

        if(!empty($_idedit)){// update
            $data_seminar['id']=$_idedit;//?3
            $this->seminar->update($data_seminar);
        }else{//data baru
            $this->seminar->simpan($data_seminar);
        }
        redirect('seminar','refresh');
        /*
        $data['list_dosen'] = $this->dosen->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('dosen/index', $data);
            $this->load->view('layouts/footer'); */
    }
    public function edit($id){
        $this->load->model('seminar_model', 'seminar');
        $obj_seminar = $this->seminar->findById($id);
        $data['objseminar']=$obj_seminar;
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('seminar/edit', $data);
            $this->load->view('layouts/footer');
    }
    public function delete($id){
        $this->load->model('seminar_model', 'seminar');
        $data_seminar['id']=$id;
        $this->seminar->delete($data_seminar);
        redirect('seminar','refresh');
    }
}
?>