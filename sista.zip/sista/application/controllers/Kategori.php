<?php
class Kategori extends CI_Controller {
    public function index() {
        $this->load->model('kategori_model', 'kategori');
        $data['list_kategori'] = $this->kategori->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('kategori/index', $data);
            $this->load->view('layouts/footer');
    }
    public function create() {
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('kategori/form');
            $this->load->view('layouts/footer');
    }
    public function save(){
        $this->load->model('kategori_model', 'kategori');
        $_nama = $this->input->post('nama_kategori_seminar');
        $_idedit = $this->input->post('idedit');

        
        $data_kategori['nama_kategori_seminar']=$_nama;//?2
    
        if(!empty($_idedit)){// update
            $data_kategori['id']=$_idedit;//?3
            $this->kategori->update($data_kategori);
        }else{//data baru
            $this->kategori->simpan($data_kategori);
        }
        redirect('kategori','refresh');
        /*
        $data['list_dosen'] = $this->dosen->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('dosen/index', $data);
            $this->load->view('layouts/footer'); */
    }
    public function edit($id){
        $this->load->model('kategori_model', 'kategori');
        $obj_kategori = $this->kategori->findById($id);
        $data['objkategori']=$obj_kategori;
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('kategori/edit', $data);
            $this->load->view('layouts/footer');
    }
    public function delete($id){
        $this->load->model('kategori_model', 'kategori');
        $data_kategori['id']=$id;
        $this->kategori->delete($data_kategori);
        redirect('kategori','refresh');
    }
}
?>