<?php
class Login extends CI_Controller {
    public function index() {
            // kirim ke view
            $this->load->view('login/index');
            $this->load->view('layouts/footer');
    }
    public function auth() {
        // kirim ke view
        $username = $this->input->post("username");
        $password = $this->input->post("password");

        // Mengecek jika username berhasil maka ke halaman home, jika tidak maka balik ke login
        if ($username == "admin" && $password == "adminn"){
            redirect('team');
        }else{
            redirect('login');
        }
    }
}
?>