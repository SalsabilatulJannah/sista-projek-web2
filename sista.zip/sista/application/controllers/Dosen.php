<?php
class Dosen extends CI_Controller {
    public function index() {
        $this->load->model('dosen_model', 'dosen');
        $data['list_dosen'] = $this->dosen->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('dosen/index', $data);
            $this->load->view('layouts/footer');
    }
    public function create() {
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('dosen/form');
            $this->load->view('layouts/footer');
    }
    public function save(){
        $this->load->model('dosen_model', 'dosen');
        $_nidn = $this->input->post('nidn');
        $_nama = $this->input->post('nama_dosen');
        $_idedit = $this->input->post('idedit');

        $data_dosen['nidn']=$_nidn;
        $data_dosen['nama_dosen']=$_nama;//?2
    
        if(!empty($_idedit)){// update
            $data_dosen['id']=$_idedit;//?3
            $this->dosen->update($data_dosen);
        }else{//data baru
            $this->dosen->simpan($data_dosen);
        }
        redirect('dosen','refresh');
        /*
        $data['list_dosen'] = $this->dosen->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('dosen/index', $data);
            $this->load->view('layouts/footer'); */
    }
    public function edit($id){
        $this->load->model('dosen_model', 'dosen');
        $obj_dosen = $this->dosen->findById($id);
        $data['objdosen']=$obj_dosen;
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('dosen/edit', $data);
            $this->load->view('layouts/footer');
    }
    public function delete($id){
        $this->load->model('dosen_model','dosen');
        $data_dosen['id']=$id;
        $this->dosen->delete($data_dosen);
        redirect('dosen','refresh');
    }
    public function view($id){
        $this->load->model('dosen_model', 'dosen');
        $obj_dosen = $this->dosen->findById($id);
        $data['objdosen']=$obj_dosen;
        $data['error']='';
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('dosen/view', $data);
            $this->load->view('layouts/footer');
    }
    public function upload(){
        $_iddosen=$this->input->post("iddosen");
        $this->load->model('dosen_model', 'dosen');
        $obj_dosen = $this->dosen->findById($_iddosen);
        $data['objdosen']=$obj_dosen;

        $config [ 'upload_path' ]='./uploads/photos' ; 
        $config [ 'allowed_types' ]='gif|jpg|png' ; 
        $config [ 'max_size' ]=100; 
        $config [ 'max_width' ]=1024; 
        $config [ 'max_height' ]=768;
        $config [ 'file_name' ]=$obj_dosen->nidn;

        $this->load->library('upload',$config);

        if (!$this->upload->do_upload('foto')) 
        { 
                $data['error'] = $this->upload->display_errors();
                //$this -> load -> view ('upload_form' ,  $error ); 
        } 
        else 
        {
                $data['error']='data sukses';
                $data['upload_data'] = $this->upload->data();
                //$this -> load -> view ( 'upload_success' ,  $data ); 
        }
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('dosen/view', $data);
            $this->load->view('layouts/footer');
    }
}
?>