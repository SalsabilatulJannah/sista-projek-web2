<?php
class Detail extends CI_Controller {
    public function index() {
        $this->load->model('detailpenilaian_model', 'detail');
        $data['list_detail'] = $this->detail->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('detail/index', $data);
            $this->load->view('layouts/footer');
    }
    public function create() {
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('detail/form');
            $this->load->view('layouts/footer');
    }
    /*
    public function jeniswisata(){
        $this->load->model('Jeniswisata_model');
        // memanggil model
        $list_jenis = $this->Jeniswisata_model->getAll();
        $data['list_jenis'] = $list_jenis;
        $this->load->view('layouts/header');
        $this->load->view('wisata/form', $data);
        $this->load->view('layouts/footer');
    }*/
    public function save(){
        $this->load->model('detailpenilaian_model', 'detail');
        $_penilaian_id = $this->input->post('penilaian_id');
        $_dosen_id = $this->input->post('dosen_id');
        $_seminar_id = $this->input->post('seminar_id');
        $_nilai = $this->input->post('nilai');
        $_idedit = $this->input->post('idedit');
    
        $data_detail['penilaian_id']=$_penilaian_id;//?2
        $data_detail['dosen_id']=$_dosen_id;
        $data_detail['seminar_id']=$_seminar_id;
        $data_detail['nilai']=$_nilai;

        if(!empty($_idedit)){// update
            $data_detail['id']=$_idedit;//?3
            $this->detail->update($data_detail);
        }else{//data baru
            $this->detail->simpan($data_detail);
        }
        redirect('detail','refresh');
        /*
        $data['list_dosen'] = $this->dosen->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('dosen/index', $data);
            $this->load->view('layouts/footer'); */
    }
    public function edit($id){
        $this->load->model('detailpenilaian_model', 'detail');
        $obj_detail = $this->detail->findById($id);
        $data['objdetail']=$obj_detail;
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('detail/edit', $data);
            $this->load->view('layouts/footer');
    }
    public function delete($id){
        $this->load->model('detailpenilaian_model', 'detail');
        $data_detail['id']=$id;
        $this->detail->delete($data_detail);
        redirect('detail','refresh');
    }
}
?>