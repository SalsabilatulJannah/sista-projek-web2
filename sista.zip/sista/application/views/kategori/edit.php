<div class="container">
<h1>Form Edit Kategori Seminar</h1>
<?php echo form_open("kategori/save"); ?>
  <div class="form-group row">
    <label for="nama_kategori_seminar" class="col-4 col-form-label">Nama Kategori Seminar</label> 
    <div class="col-8">
      <input id="nama_kategori_seminar" name="nama_kategori_seminar" type="text" value="<?=$objkategori->nama_kategori_seminar?>" class="form-control">
    </div>
  </> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-success">Update</button>
    </div>
  </div>
  <input type="hidden" name="idedit" value="<?=$objkategori->id?>"/>
<?php echo form_close()?>
</div>
