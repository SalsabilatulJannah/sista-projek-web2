<script>
function hapusDosen(pesan){
    if (confirm(pesan)){
        return true;
    }
    else{
        return false;
    }
}
</script>
<table class="table">
<h2>Kategori Seminar</h2>
<thead>
<tr>
<th>No</th>
<th>ID</th>
<th>NAMA KATEGORI</th>
<th>ACTION</th>
</tr>
</thead>
<tbody>
<?php 
$nomor=1;
foreach ($list_kategori->result() as $row) {
    echo '<tr><td>'.$nomor.'</td>';
    echo '<td>'.$row->id .'</td>';
    echo '<td>'.$row->nama_kategori_seminar .'</td>';
    echo '<td>
    <a href="'.base_url().'index.php/kategori/edit/'.$row->id.'" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Edit</a>
    <a href="'.base_url().'index.php/kategori/delete/'.$row->id.'" class="btn btn-danger btn-lg active" role="button" aria-pressed="true" 
    onclick="return hapusDosen(\'Data Kategori yang bernama ' .$row->nama_kategori_seminar.' Yakin Mau dihapus ? \')">Hapus</a>
    <td/>';
    echo '</tr>';
    $nomor++;
} ?>
</tbody>
</table>
<a href="<?=base_url()?>index.php/kategori/create" class="btn btn-warning btn-lg active" role="button" aria-pressed="true">Tambah</a>