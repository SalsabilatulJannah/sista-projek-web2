<div class="container">
<h1>Form Kategori Seminar</h1>
<?php echo form_open("kategori/save"); ?> 
  <div class="form-group row">
    <label for="nama_kategori_seminar" class="col-4 col-form-label">NAMA KATEGORI SEMINAR</label> 
    <div class="col-8">
      <input id="nama_kategori_seminar" name="nama_kategori_seminar" type="text" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
<?php echo form_close()?>
</div>