<script>
function hapusDosen(pesan){
    if (confirm(pesan)){
        return true;
    }
    else{
        return false;
    }
}
</script>
<table class="table">
<h2>Peserta Seminar</h2>
<thead>
<tr>
<th>No</th>
<th>ID</th>
<th>NIM</th>
<th>Kehadiran</th>
<th>Nama Peserta</th>
<th>ACTION</th>
</tr>
</thead>
<tbody>
<?php 
$nomor=1;
foreach ($list_peserta->result() as $row) {
    echo '<tr><td>'.$nomor.'</td>';
    echo '<td>'.$row->id .'</td>';
    echo '<td>'.$row->nim .'</td>';
    echo '<td>'.$row->kehadiran .'</td>';
    echo '<td>'.$row->nama_peserta_seminar .'</td>';
    echo '<td>
    <a href="'.base_url().'index.php/peserta/edit/'.$row->id.'" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Edit</a>
    <a href="'.base_url().'index.php/peserta/delete/'.$row->id.'" class="btn btn-danger btn-lg active" role="button" aria-pressed="true" 
    onclick="return hapusDosen(\'Data Peserta yang ber Bernama ' .$row->nama_peserta_seminar.' Yakin Mau dihapus ? \')">Hapus</a>
    <td/>';
    echo '</tr>';
    $nomor++;
} ?>
</tbody>
</table>
<a href="<?=base_url()?>index.php/peserta/create" class="btn btn-warning btn-lg active" role="button" aria-pressed="true">Tambah</a>