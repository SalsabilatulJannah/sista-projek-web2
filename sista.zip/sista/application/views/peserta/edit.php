<h1>Form Edit Peserta</h1>
<?php echo form_open("peserta/save"); ?>
<div class="form-group row">
    <label for="nim" class="col-4 col-form-label">Nim</label> 
    <div class="col-8">
      <input id="nim" name="nim" type="text" value="<?=$objpeserta->nim?>" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="nama_peserta_seminar" class="col-4 col-form-label">Nama Peserta</label> 
    <div class="col-8">
      <input id="nama_peserta_seminar" name="nama_peserta_seminar" type="text" value="<?=$objpeserta->nama_peserta_seminar?>" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <label for="kehadiran" class="col-4 col-form-label">Kehadiran</label> 
    <div class="col-8">
      <input id="kehadiran" name="kehadiran" type="text" value="<?=$objpeserta->kehadiran?>" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
  <input type="hidden" name="idedit" value="<?=$objpeserta->id?>"/>
<?php echo form_close()?>
