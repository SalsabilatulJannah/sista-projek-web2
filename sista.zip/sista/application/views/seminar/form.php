<div class="container">
<h1>Form Seminar Tugas Akhir</h1>
<?php echo form_open("seminar/save"); ?>
<div class="form-group row">
    <label for="peserta_seminar_id" class="col-4 col-form-label">Id Peserta Seminar</label> 
    <div class="col-8">
    <select class="form-control" id="peserta_seminar_id" name="peserta_seminar_id">
    <?php
                  include "config.php";
                  $result= mysqli_query ($connect, "SELECT * FROM peserta_seminar ");
                    while ($row = mysqli_fetch_array($result))
                  { ?>
                      <option value="<?php echo $row[0] ?>"><?php echo $row[0] ?></option>
                  <?php }  ?>  
                    </select>
    </div>
  </div> 
  <div class="form-group row">
    <label for="semester" class="col-4 col-form-label">Semester</label> 
    <div class="col-8">
      <input id="semester" name="semester" type="text" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <label for="tanggal" class="col-4 col-form-label">Tanggal</label> 
    <div class="col-8">
      <input id="tanggal" name="tanggal" type="date" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="jam" class="col-4 col-form-label">Jam</label> 
    <div class="col-8">
      <input id="jam" name="jam" type="text" class="form-control">
    </div>
  </div>  
  <div class="form-group row">
    <label for="kategori_seminar_id" class="col-4 col-form-label">Kategori Seminar ID</label> 
    <div class="col-8">
    <select class="form-control" id="kategori_seminar_id" name="kategori_seminar_id">
    <?php
                  include "config.php";
                  $result= mysqli_query ($connect, "SELECT * FROM kategori_seminar ");
                    while ($row = mysqli_fetch_array($result))
                  { ?>
                      <option value="<?php echo $row[0] ?>"><?php echo $row[0] ?></option>
                  <?php }  ?>  
                    </select>
    </div>
  </div> 
  <div class="form-group row">
    <label for="judul" class="col-4 col-form-label">Judul</label> 
    <div class="col-8">
      <input id="judul" name="judul" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="pembimbing_id" class="col-4 col-form-label"> Pembimbing ID</label> 
    <div class="col-8">
    <select class="form-control" id="pembimbing_id" name="pembimbing_id">
    <?php
                  include "config.php";
                  $result= mysqli_query ($connect, "SELECT * FROM dosen ");
                    while ($row = mysqli_fetch_array($result))
                  { ?>
                      <option value="<?php echo $row[0] ?>"><?php echo $row[0] ?></option>
                  <?php }  ?>  
                    </select>
    </div>
  </div> 
  <div class="form-group row">
    <label for="penguji1_id" class="col-4 col-form-label">Id Penguji 1</label> 
    <div class="col-8">
    <select class="form-control" id="penguji1_id" name="penguji1_id">
    <?php
                  include "config.php";
                  $result= mysqli_query ($connect, "SELECT * FROM penguji ");
                    while ($row = mysqli_fetch_array($result))
                  { ?>
                      <option value="<?php echo $row[0] ?>"><?php echo $row[0] ?></option>
                  <?php }  ?>  
                    </select>
    </div>
  </div>
  <div class="form-group row">
    <label for="penguji2_id" class="col-4 col-form-label">Id Penguji 2</label> 
    <div class="col-8">
    <select class="form-control" id="penguji2_id" name="penguji2_id">
    <?php
                  include "config.php";
                  $result= mysqli_query ($connect, "SELECT * FROM penguji ");
                    while ($row = mysqli_fetch_array($result))
                  { ?>
                      <option value="<?php echo $row[0] ?>"><?php echo $row[0] ?></option>
                  <?php }  ?>  
                    </select>
    </div>
  </div> 
  <div class="form-group row">
    <label for="nilai_pembimbing" class="col-4 col-form-label">Nilai Pembimbing</label> 
    <div class="col-8">
      <input id="nilai_pembimbing" name="nilai_pembimbing" type="text" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <label for="nilai_penguji1" class="col-4 col-form-label">Nilai Penguji 1</label> 
    <div class="col-8">
      <input id="nilai_penguji1" name="nilai_penguji1" type="text" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <label for="nilai_penguji2" class="col-4 col-form-label">Nilai Penguji 2</label> 
    <div class="col-8">
      <input id="nilai_penguji2" name="nilai_penguji2" type="text" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <label for="nilai_akhir" class="col-4 col-form-label">Nilai Akhir</label> 
    <div class="col-8">
      <input id="nilai_akhir" name="nilai_akhir" type="text" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <label for="lokasi" class="col-4 col-form-label">Lokasi</label> 
    <div class="col-8">
      <input id="lokasi" name="lokasi" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
<?php echo form_close()?>
</div>