<script>
function hapusDosen(pesan){
    if (confirm(pesan)){
        return true;
    }
    else{
        return false;
    }
}
</script>
<table class="table">
<h2>Seminar</h2>
<thead>
<tr>
<th>No</th>
<th>Id</th>
<th>Peserta Seminar</th>
<th>Semester</th>
<th>Penguji 1</th>
<th>Penguji 2</th>
<th>Pembimbing Id</th>
<th>Tanggal</th>
<th>Jam</th>
<th>Judul</th>
<th>Kategori Seminar</th>
<th>Nilai Pembimbing</th>
<th>Nilai Penguji 1</th>
<th>Nilai Penguji 2</th>
<th>Nilai Akhir</th>
<th>Lokasi</th>
<th>ACTION</th>
</tr>
</thead>
<tbody>
<?php 
$nomor=1;
foreach ($list_seminar->result() as $row) {
    echo '<tr><td>'.$nomor.'</td>';
    echo '<td>'.$row->id .'</td>';
    echo '<td>'.$row->peserta_seminar_id .'</td>';
    echo '<td>'.$row->semester .'</td>';
    echo '<td>'.$row->penguji1_id .'</td>';
    echo '<td>'.$row->penguji2_id .'</td>';
    echo '<td>'.$row->pembimbing_id .'</td>';
    echo '<td>'.$row->tanggal .'</td>';
    echo '<td>'.$row->jam .'</td>';
    echo '<td>'.$row->judul .'</td>';
    echo '<td>'.$row->kategori_seminar_id .'</td>';
    echo '<td>'.$row->nilai_pembimbing .'</td>';
    echo '<td>'.$row->nilai_penguji1 .'</td>';
    echo '<td>'.$row->nilai_penguji2 .'</td>';
    echo '<td>'.$row->nilai_akhir .'</td>';
    echo '<td>'.$row->lokasi .'</td>';
    echo '<td>
    <a href="'.base_url().'index.php/seminar/edit/'.$row->id.'" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Edit</a>
    <a href="'.base_url().'index.php/seminar/delete/'.$row->id.'" class="btn btn-danger btn-lg active" role="button" aria-pressed="true" 
    onclick="return hapusDosen(\'Data seminar yang Ber ID ' .$row->peserta_seminar_id.' Yakin Mau dihapus ? \')">Hapus</a>
    <td/>';
    echo '</tr>';
    $nomor++;
} ?>
</tbody>
</table>
<a href="<?=base_url()?>index.php/seminar/create" class="btn btn-warning btn-lg active" role="button" aria-pressed="true">Tambah</a>