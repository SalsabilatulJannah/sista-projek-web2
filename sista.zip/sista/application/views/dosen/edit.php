<h1>Form Edit Data Dosen</h1>
<?php echo form_open("dosen/save"); ?>
<div class="form-group row">
    <label for="nidn" class="col-4 col-form-label">NIDN</label> 
    <div class="col-8">
      <input id="nidn" name="nidn" type="text" value="<?=$objdosen->nidn?>" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="nama_dosen" class="col-4 col-form-label">NAMA</label> 
    <div class="col-8">
      <input id="nama_dosen" name="nama_dosen" type="text" value="<?=$objdosen->nama_dosen?>" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-success">Update</button>
    </div>
  </div>
  <input type="hidden" name="idedit" value="<?=$objdosen->id?>"/>
<?php echo form_close()?>
