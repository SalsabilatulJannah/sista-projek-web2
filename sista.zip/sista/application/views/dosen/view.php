<div class="container">
    <div class="main-body">
    <div>
    <h2>Profile</h2>
    </div>
          <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                  <img src="<?=base_url()?>uploads/photos/<?=$objdosen->nidn?>.jpg" class="rounded-circle" width="150"/>
                    <div class="mt-3">
                      <h4><?=$objdosen->nama_dosen?></h4>
                      <!-- <p class="text-secondary mb-1">Full Stack Developer</p> -->
                      <p class="text-muted font-size-sm">Dosen Sekolah Tinggi Teknologi Terpadu Nurul Fikri</p>
                      <!--<button class="btn btn-primary">Follow</button>
                      <button class="btn btn-outline-primary">Message</button>
                      -->
                      <?php echo $error;?>

<?php echo form_open_multipart('dosen/upload');?>

<input type="file" name="foto" size="20" />
<input type="hidden" name="iddosen" value="<?=$objdosen->id?>"/>

<br/><br/>

<input type="submit" value="Upload Foto" class="btn btn-primary"/>

</form>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card mt-3">
                
              </div>
            </div>
            <div class="col-md-8">
              <div class="card mb-3">
                <div class="card-body">
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">ID</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                    <?=$objdosen->id?>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Nama Dosen</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                    <?=$objdosen->nama_dosen?>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">NIDN</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?=$objdosen->nidn?>
                    </div>
                  </div>
                  <hr>
                </div>
              </div>

                </div>
              </div>



            </div>
          </div>

        </div>
    </div>