<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Sistem Informasi Seminar Tugas Akhir</title>

  <!-- Bootstrap core CSS -->
  <link href="<?php echo base_url('assets/vendor/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="<?php echo base_url('assets/css/simple-sidebar.css')?>" rel="stylesheet">

</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
    <img class="sidebar-heading" src="<?=base_url("\assets\sttnf.PNG")?>" alt="LOGO STT-NF" width="130px">
      <div class="sidebar-heading"><h1>SISTA NF</h1>
      </div>
      <div class="list-group list-group-flush">
      <a href="http://localhost/sista/" class="list-group-item list-group-item-action bg-light">Welcome</a>
      <a href="http://localhost/sista/index.php/seminar/index" class="list-group-item list-group-item-action bg-light">Seminar</a>
        <a href="http://localhost/sista/index.php/peserta/index" class="list-group-item list-group-item-action bg-light">Peserta</a>
        <a href="http://localhost/sista/index.php/kategori/index" class="list-group-item list-group-item-action bg-light">Kategori Seminar</a>
        <a href="http://localhost/sista/index.php/penguji/index" class="list-group-item list-group-item-action bg-light">Penguji</a>
        <a href="http://localhost/sista/index.php/dosen/index" class="list-group-item list-group-item-action bg-light">Dosen</a>
        <a href="http://localhost/sista/index.php/penilaian/index" class="list-group-item list-group-item-action bg-light">Penilaian</a>
        <a href="http://localhost/sista/index.php/detail/index" class="list-group-item list-group-item-action bg-light">Detail Penilaian</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->
    <!-- Page Content -->
<div id="page-content-wrapper">

  <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
      <button class="btn btn-primary" id="menu-toggle">Menu</button>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
          <li class="nav-item active">
              <a class="nav-link" href="http://localhost/sista/">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
              <a class="nav-link" href="http://localhost/sista/index.php/team/index">Team <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item dropdown">
          <a class="nav-link" href="http://localhost/sista/index.php/login/index">Login</a>
              <!-- <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="#">Action</a>
              <a class="dropdown-item" href="#">Another action</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">Something else here</a>
              </div> -->
          </li>
          </ul>
      </div>
  </nav>