<div class="container">
<html>
    <h1 style = 'text-align : center;'>Sistem Informasi Seminar Tugas Akhir</h1>
<section class="bagian-baground">
					<div class="container">
						<div class="intro">
							<img class="intro-img img-fluid mb-3 mb-lg-0 rounded" src="<?php echo base_url('/home.png')?>" alt="">
							<div class="intro-text left-0 text-center bg-faded p-5 rounded">
							</div>
				</section>
				<h3>Tentang SISTA</h3>
				<p class="ket-par ">
					SISTA merupakan Sistem Informasi Seminar Tugas Akhir di Sekolah Tinggi Teknologi Terpadu Nurul Fikri berbasis website yang digunakan untuk memfasilitasi mahasiswa dalam melakukan tugas akhir sehingga dalam pengerjaan tugas akhir tersebut dapet efektif dan efesien.Mahasiswa dan dosen tidak perlu untuk selalu melakukan dengan tatap muka setiap kali melakukan bimbingan sehingga permasalahan yang dihadapi dalam pengerjaan tugas akhir tersebut dapat diselesaikan lebih cepat.Adapun, jika proses ini tidak di tempuh mahasiswa maka tidak akan dapat mendaftar wisuda meskipun sudah melaksanakan sidang Sarjana maupun Diploma di Program Studi.
					<br>  
				</p>
			</div>
</html>
</div>