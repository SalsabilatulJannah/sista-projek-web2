<div class="container">
<h1>Form Edit Detail Penilaian</h1>
<?php echo form_open("detail/save"); ?>
<div class="form-group row">
    <label for="penilaian_id" class="col-4 col-form-label">Penilaian Id</label> 
    <div class="col-8">
    <select class="form-control" id="penilaian_id" name="penilaian_id" value="<?=$objdetail->penilaian_id?>">
    <?php
                  include "config.php";
                  $result= mysqli_query ($connect, "SELECT * FROM penilaian ");
                    while ($row = mysqli_fetch_array($result))
                  { ?>
                      <option value="<?php echo $row[0] ?>"><?php echo $row[0] ?></option>
                  <?php }  ?>  
                    </select>
    </div>
  </div> 
  <div class="form-group row">
    <label for="dosen_id" class="col-4 col-form-label">Dosen Id</label> 
    <div class="col-8">
    <select class="form-control" id="dosen_id" name="dosen_id" value="<?=$objdetail->dosen_id?>">
    <?php
                  include "config.php";
                  $result= mysqli_query ($connect, "SELECT * FROM dosen ");
                    while ($row = mysqli_fetch_array($result))
                  { ?>
                      <option value="<?php echo $row[0] ?>"><?php echo $row[0] ?></option>
                  <?php }  ?>  
                    </select>
    </div>
  </div> 
  <div class="form-group row">
    <label for="seminar_id" class="col-4 col-form-label">Seminar Id</label> 
    <div class="col-8">
    <select class="form-control" id="seminar_id" name="seminar_id" value="<?=$objdetail->seminar_id?>">
    <?php
                  include "config.php";
                  $result= mysqli_query ($connect, "SELECT * FROM seminar_ta ");
                    while ($row = mysqli_fetch_array($result))
                  { ?>
                      <option value="<?php echo $row[0] ?>"><?php echo $row[0] ?></option>
                  <?php }  ?>  
                    </select>
    </div>
  </div> 
  <div class="form-group row">
    <label for="nilai" class="col-4 col-form-label">Nilai</label> 
    <div class="col-8">
      <input id="nilai" name="nilai" type="text" class="form-control" value="<?=$objdetail->nilai?>">
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
  <input type="hidden" name="idedit" value="<?=$objdetail->id?>"/>
<?php echo form_close()?>
</div>