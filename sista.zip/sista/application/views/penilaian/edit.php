<h1>Form Edit Penilaian</h1>
<?php echo form_open("penilaian/save"); ?>
<div class="form-group row">
    <label for="nama_penilaian" class="col-4 col-form-label">Nama Penilaian</label> 
    <div class="col-8">
      <input id="nama_penilaian" name="nama_penilaian" type="text" value="<?=$objpenilaian->nama_penilaian?>" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <label for="keterangan" class="col-4 col-form-label">Keterangan</label> 
    <div class="col-8">
      <input id="keterangan" name="keterangan" type="text" value="<?=$objpenilaian->keterangan?>" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
  <input type="hidden" name="idedit" value="<?=$objpenilaian->id?>"/>
<?php echo form_close()?>
